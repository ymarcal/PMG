global Dados;
learn();