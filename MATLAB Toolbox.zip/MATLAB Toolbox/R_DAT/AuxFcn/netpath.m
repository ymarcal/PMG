function netpath = netpath
% Fornece o caminho de rede para os arquivos do R_DAT

% At� 11/04/2012
% netpath = '\\BETA\GEEV\GEEV_TECNICO\PROGRAMAS COMPUTACIONAIS\MATLAB\R_DAT\';

% Ap�s 12/04/2012
netpath = '\\beta\Arquivo\!GT\T�cnico\PROGRAMAS COMPUTACIONAIS\MATLAB\R_DAT\';