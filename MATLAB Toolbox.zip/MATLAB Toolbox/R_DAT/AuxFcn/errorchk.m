function out = errorchk
% Fun�ao que verifica se houve esgotamento de mem�ria ou erro de execu�ao

[err_msg, err_id] = lasterr;

if ~isempty(err_msg)
    out = 1;
    if strcmp(err_id,'MATLAB:nomem')
        beep; errordlg({'N�o houve mem�ria suficiente para realizar a opera��o.',...
                'Libere mais espa�o ou reduza o arquivo de trabalho.',' ',...
                '                             ATEN��O:',...
                'A matriz de dados pode ter sido corrompida, portanto',...
                '� altamente recomendado fechar, reiniciar o R_DAT',...
                'e continuar a partir do �ltimo arquivo salvo.'},'Erro','modal'); drawnow;
    else
        beep; errordlg({err_id,err_msg,'','Favor reportar este erro ao programador respons�vel,',...
                'descrevendo as circunst�ncias em que o mesmo ocorreu.'},'Erro','modal'); drawnow;
    end
        lasterr('');
else
    out = 0;
end
